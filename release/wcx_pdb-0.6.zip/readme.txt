WCX_PDB 0.6
-----------
4 jan 2008


Wcx plugin for Total Commander. 
WCX_PDB allows you to open (Ctrl+PageDown) Palm DB files (*.pdb), 
view records, extract the content and create (Alt+F5) new Data Bases.

Language changes automatically by using Windows' locale. 
English, russian and ukrainian languages are present now.

ZLIB1.DLL needed for zTXT format.

-----------------
Oleksandr Bogomaz
albom85@yandex.ru
http://albom06.boom.ru
